angular.module("msForm.controllers",[])

.factory('Authorization', function() {
 
  authorization = {};
  authorization.firstname = '';
  authorization.lastname = ''; 
  authorization.phone = '';
  authorization.email = '';
  authorization.degree = ''; 
    authorization.dob = '';
	 authorization.sex = ''; 
	authorization.address = '';
  return authorization;
})

.factory("LS", function($localStorage) {
  return {
    setFormData:function(val){
       alert()
    },
    setData: function(val) {
      alert(" ls set data");
      $localStorage.values=val;
       console.log("values"+$localStorage.values.firstname+ $localStorage.values.lastname);
      return this;
    },
    getData: function() {
    	alert("get adata called");
      return $localStorage.values;
    }
  }
})

.controller('login',function($scope,$state,Authorization){
	
	// $scope.formdetails = Authorization; 
		$scope.formdetails=Authorization;

	$scope.loginSubmit=function(){
	   alert("first name " +$scope.formdetails.firstname  + "last name" +$scope.formdetails.lastname);	
	}
})

.controller('personal',function($scope,$state,Authorization){
		$scope.personalDetails=Authorization;
	$scope.personalFormSubmit=function(){
	//$localStorage.localmessage="hai";  
	}
})

.controller('educational',function($scope,$state,Authorization,LS,localStorageService){
	var taskdata='tasks';
	$scope.eduDetails=Authorization;
	$scope.formSubmit=function(){
	   //$scope.localStorage= Authorization;
    //console.log("task variable",taskdata);
   //localStorageService.set(taskdata,$scope.formSubmit);
    $scope.formdata=Authorization;
    $localStorage=$scope.formdata;
    LS.setData($scope.formdata);
    console.log($localStorage);
       alert("submit button pressed" + $scope.eduDetails.degree);	
	   $state.go('signin');
	}
})

 


.controller('welcomectrl', function($scope, $localStorage,Authorization,$sessionStorage) {
	//console.log(Authorization);
  $scope.formdetails = Authorization; 
   	//$localStorage = $scope.formdetails;
    //console.log($scope.formdetails);
   //alert($localStorage.firstname);
     //console.log($localStorage.firstname);
   //$localStorage.localmessage="hai";
  
  //$localStorage.formdetails=formdetails;
  //console.log($localStorage);
  //alert($localStorage.firstname + "" + $localStorage.sex + "" + $localStorage.degree);
})

.controller('signin', function($scope,LS,$state,localStorageService) {
	//$localStorage=Authorization;
       // $scope.todo=localStorageService.get(taskdata);
        //console.log($scope.todo);
     $scope.details=LS.getData();
     $scope.data={};
     console.log($scope.details.firstname + $scope.details.lastname);
    $scope.login=function(){
       console.log($scope.data.username);

       if($scope.details.firstname == $scope.data.username){
         alert("value matches");
          $state.go('welcome');
       }else
         alert("value not matched ");
	  }


});