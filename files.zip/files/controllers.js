angular.module("starter.controllers",[])



.controller('loginController',function($scope,$state){
	
	
	$scope.login=function(){
		
       alert("submit button pressed"  );	
	}
});