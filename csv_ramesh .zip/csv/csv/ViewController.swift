//
//  ViewController.swift
//  csv
//
//  Created by Boobesh Balasubramanian on 14/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UIGestureRecognizerDelegate {
    
    /*Collection of outlets and actions for the matched view controller  */
    
    
    @IBOutlet weak var FirstNameTextfield: UITextField!
    @IBOutlet weak var LastNameTextField: UITextField!
    @IBOutlet weak var TitleTextField: UITextField!
    @IBOutlet weak var PhoneNumberTextField: UITextField!
    @IBOutlet weak var EmailAddressTextField: UITextField!
    @IBOutlet weak var Company: UITextField!
    @IBOutlet weak var ListOfProductsLabel: UILabel!
    @IBOutlet weak var DeploymentTypeLabel: UILabel!
    @IBOutlet weak var OrganisationTypeLabel: UILabel!
    @IBOutlet weak var TimeFrameLabel: UILabel!
    @IBOutlet weak var NotesTextField: UITextView!
    @IBOutlet weak var AccountTypeLabel: UILabel!
    @IBOutlet weak var UrgencyTypeLabel: UILabel!
    
    @IBAction func SubmitFormButton(_ sender: UIButton) {
       
        let firsName = FirstNameTextfield.text
        let lastName = LastNameTextField.text
        let title = TitleTextField.text
        let phoneNumber = PhoneNumberTextField.text
        let email = EmailAddressTextField.text
        let comoany = Company.text
        let notes = NotesTextField.text
        let selectedProducts = labelsValuesDictionary["IManageProducts"]
        let selectedDeployment_Types = labelsValuesDictionary["DeploymentTypes"]
        let selectedOrganisation_Types = labelsValuesDictionary["TypeOfOrganisations"]
        let selectedtimeFrame = labelsValuesDictionary["TimeFrame"]
        let selectedAccountType = labelsValuesDictionary["SDFCAccountType"]
        let selectedUrgencyType = labelsValuesDictionary["urgency"]
        
        
        print("the form values are \(firsName) \(lastName)\(title)\(phoneNumber)\(email)\(comoany)\(notes)\(selectedProducts)\(selectedDeployment_Types)\(selectedOrganisation_Types)\(selectedtimeFrame)\(selectedAccountType)\(selectedUrgencyType)")

    }
    
    
    
    /* Datasource array's for the picker view  */
    
    let IManageProducts = ["iManage work", "iManage Share"," iManage Insight", "iManage govern" , "MFP integration", "Process Automation"]
    let DeploymentTypes = ["Onpremis", "cloud"]
    let TypeOfOrganisations = ["Law firm", "Corporate legal departmnet"]
    let TimeFrame = ["In the next 12 months", "12 to 24 months", "more than 24 months"]
    let SDFCAccountType = ["Client", "Prospect"]
    let urgency = ["1","2","3"]
    let labelNamesArray = ["IManageProducts","DeploymentTypes","TypeOfOrganisations","TimeFrame","SDFCAccountType","urgency"]
    var labelsArray = Array<Array<String>>()
    var labelsValuesDictionary = [String:String]()
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /* adding gestures to the corresponding views */
        
        labelsArray.append(IManageProducts)
        labelsArray.append(DeploymentTypes)
        labelsArray.append(TypeOfOrganisations)
        labelsArray.append(TimeFrame)
        labelsArray.append(SDFCAccountType)
        labelsArray.append(urgency)
        
        ListOfProductsLabel.addGestureRecognizer(gestureProvider())
        DeploymentTypeLabel.addGestureRecognizer(gestureProvider())
        OrganisationTypeLabel.addGestureRecognizer(gestureProvider())
        TimeFrameLabel.addGestureRecognizer(gestureProvider())
        AccountTypeLabel.addGestureRecognizer(gestureProvider())
        UrgencyTypeLabel.addGestureRecognizer(gestureProvider())
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func labelTapGestureHandler(sender:UITapGestureRecognizer){
        generatePicker(pickerTags: sender.view!.tag)
    }
    
    
    func gestureProvider()->UITapGestureRecognizer{
        print("gesture provided to all labels ")
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(labelTapGestureHandler(sender:)))
        tapGesture.delegate = self
        tapGesture.numberOfTouchesRequired = 1
        tapGesture.numberOfTapsRequired = 1
        return tapGesture
        
    }
    
    
    func generatePicker(pickerTags:Int) {
        let vc = UIViewController()
        vc.preferredContentSize = CGSize(width: 250,height: 300)
        let pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: 250, height: 300))
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.tag = pickerTags
        vc.view.addSubview(pickerView)
        let pickerAlert = UIAlertController(title: "choose \(labelNamesArray[pickerTags])", message: "", preferredStyle: UIAlertControllerStyle.alert)
        pickerAlert.setValue(vc, forKey: "contentViewController")
        pickerAlert.addAction(UIAlertAction(title: "Done", style: .default, handler: nil))
        pickerAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(pickerAlert, animated: true)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return givePickerCount(forPickerView:pickerView)
    }
    
    func givePickerCount(forPickerView:UIPickerView)->Int{
        switch forPickerView.tag {
        case 0:
            return IManageProducts.count
        case 1:
            return DeploymentTypes.count
        case 2:
            return TypeOfOrganisations.count
        case 3:
            return TimeFrame.count
        case 4:
            return SDFCAccountType.count
        case 5:
            return urgency.count
        default:
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let titleArray = labelsArray[pickerView.tag]
        return titleArray[row]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let titleArray = labelsArray[pickerView.tag]
        print(labelsArray[pickerView.tag][row])
        print(titleArray[row])
        updateFormFieldData(selectedPickerView: pickerView, selectedrow: row)
        
    }
    
    func updateFormFieldData(selectedPickerView pickerView:UIPickerView , selectedrow row:Int){
        identifyLabel(selectedPickerView: pickerView).text = labelsArray[pickerView.tag][row]
        labelsValuesDictionary.updateValue(labelsArray[pickerView.tag][row], forKey:labelNamesArray[pickerView.tag] )
        print("key is \(labelNamesArray[pickerView.tag]) and the value is \(labelsArray[pickerView.tag][row])")
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 36.0
    }
    
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 200
    }
    
    func identifyLabel(selectedPickerView pickerView:UIPickerView) -> UILabel{
        switch pickerView.tag {
        case 0:
            return ListOfProductsLabel
        case 1:
            return DeploymentTypeLabel
        case 2:
            return OrganisationTypeLabel
        case 3:
            return TimeFrameLabel
        case 4:
            return AccountTypeLabel
        case 5:
            return UrgencyTypeLabel
        default:
            return ListOfProductsLabel
        }

    }
    
}

